# Live_News_By_Team_QuBit
A live news portal project developed by Team_QuBit. 
<hr> <br>

## Team Members and Student ID
- Naim Istiak Masum **181-15-1793** <br>
- Hasibur Rahman **181-15-1777** <br>
- Md. Emtiyaz Ahmed **181-15-1839**  <br>
- Mahmudul Hasan **181-15-1920** <br>
- Md. Yehsun Mehedee **181-15-1962** <br>

### Trello Link [click here](https://trello.com/b/v3UdKVCD "Live News by Team_QuBit")
### Prototype Design [click here](https://teamqubit.invisionapp.com/console/share/V42GTGT2N8 "Live News by Team_QuBit")
