<?php 

    $connection = mysqli_connect('localhost','root','','live_news') or die("not connected". mysqli_error());


?>